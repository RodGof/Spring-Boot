package ProjectCracha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoProjectCrachaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoProjectCrachaApplication.class, args);
	}

}
